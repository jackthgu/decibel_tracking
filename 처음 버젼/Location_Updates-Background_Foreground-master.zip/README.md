# Location_Updates-Background_Foreground

Today(20/03/2019).

After 2 months of searching I found a best code for Oreo and above devices.

**_Feature of this Code_**

 **1.** This code works very well, here you can update a location when app is in background or in foreground.
 
 **2.** It is also work when you device will lock.
 
 **3.** It will work when user offline.
 
 I am searching a this type of code which will works in Oreo and Pie devices very well.

So I can say this is the best code for location updates and fullfil all my requirements.

**_Note_**

I founded this code in location sample code of **Google.**

**Code Provided By a Google**

**_Need Help_**
I want to turn on or turn off feature of location with help of toggle button instead of buttons
