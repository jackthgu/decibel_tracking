package com.example.serverdata2;

public class locationWorker {
}
